1) Following are the 10 full-text PubMed articles annotated by domain expert. 
pmid8301357.txt
pmid11119693.txt
pmid12389210.txt
pmid12746864.txt
pmid12836178.txt
pmid12866129.txt
pmid15116397.txt
pmid15514932.txt
pmid16134135.txt
pmid16304681.txt

2) Each file is tab seperated and has the folowing fields:
Connection status: 0:Not connected, 1:Connected
Species: optional field (annotated if evidence of species found in sentence)
BR1: Brain Region 1
BR2: Brain Region 2
Sentence: Text of sentence with brain regions marked up

3)10NeuroPubMed-MergedExpanded.txt
This is the merged file containing all sentences from the ten files along with the corresponding ground truth (Connection status) in the following line after each sentence
